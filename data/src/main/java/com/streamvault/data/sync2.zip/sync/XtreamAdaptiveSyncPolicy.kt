package com.streamvault.data.sync

import com.streamvault.data.remote.xtream.XtreamAuthenticationException
import com.streamvault.data.remote.xtream.XtreamNetworkException
import com.streamvault.data.remote.xtream.XtreamRequestException
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.delay

internal class XtreamAdaptiveSyncPolicy {
    enum class Stage(val timeoutMs: Long) {
        LIGHTWEIGHT(20_000L),
        CATEGORY(45_000L),
        HEAVY(90_000L)
    }

    private data class ProviderHealth(
        val stressLevel: Int = 0,
        val backoffUntilMs: Long = 0L,
        val successStreak: Int = 0,
        val timeoutStreak: Int = 0,
        val resetStreak: Int = 0
    )

    private val providerHealth = ConcurrentHashMap<Long, ProviderHealth>()

    suspend fun awaitTurn(providerId: Long) {
        val waitMs = (providerHealth[providerId]?.backoffUntilMs ?: 0L) - System.currentTimeMillis()
        if (waitMs > 0L) {
            delay(waitMs)
        }
    }

    fun timeoutFor(providerId: Long, stage: Stage): Long {
        val stressLevel = providerHealth[providerId]?.stressLevel ?: 0
        val multiplier = when {
            stressLevel >= 4 -> 0.7f
            stressLevel >= 2 -> 0.85f
            else -> 1f
        }
        return (stage.timeoutMs * multiplier).toLong().coerceAtLeast(15_000L)
    }

    fun concurrencyFor(
        providerId: Long,
        workloadSize: Int,
        preferSequential: Boolean
    ): Int {
        if (preferSequential || workloadSize <= 1) {
            return 1
        }
        val health = providerHealth[providerId] ?: ProviderHealth()
        val base = when {
            workloadSize <= 3 -> 2
            workloadSize <= 10 -> 3
            else -> 4
        }
        val adjusted = when {
            health.stressLevel >= 4 -> 1
            health.stressLevel >= 3 -> base - 2
            health.stressLevel >= 2 -> base - 1
            else -> base
        }
        return adjusted.coerceIn(1, 5).coerceAtMost(workloadSize)
    }

    fun recordSuccess(providerId: Long) {
        providerHealth.compute(providerId) { _, current ->
            val state = current ?: ProviderHealth()
            val nextSuccessStreak = (state.successStreak + 1).coerceAtMost(6)
            val recoveredStress = if (nextSuccessStreak >= 2) {
                (state.stressLevel - 1).coerceAtLeast(0)
            } else {
                state.stressLevel
            }
            state.copy(
                stressLevel = recoveredStress,
                backoffUntilMs = if (recoveredStress == 0) 0L else state.backoffUntilMs,
                successStreak = nextSuccessStreak,
                timeoutStreak = 0,
                resetStreak = 0
            )
        }
    }

    fun recordFailure(providerId: Long, error: Throwable) {
        providerHealth.compute(providerId) { _, current ->
            val state = current ?: ProviderHealth()
            val signal = classify(error)
            val nextStress = when (signal) {
                StressSignal.THROTTLED -> (state.stressLevel + 2).coerceAtMost(5)
                StressSignal.TIMEOUT,
                StressSignal.CONNECTION_RESET -> (state.stressLevel + 1).coerceAtMost(5)
                StressSignal.NONE -> state.stressLevel
            }
            val nextTimeoutStreak = if (signal == StressSignal.TIMEOUT) state.timeoutStreak + 1 else 0
            val nextResetStreak = if (signal == StressSignal.CONNECTION_RESET) state.resetStreak + 1 else 0
            val extraStress = when {
                nextTimeoutStreak >= 2 || nextResetStreak >= 2 -> 1
                else -> 0
            }
            val finalStress = (nextStress + extraStress).coerceAtMost(5)
            val backoffMs = when {
                signal == StressSignal.THROTTLED -> 1_500L * finalStress
                signal != StressSignal.NONE -> 800L * finalStress
                else -> 0L
            }
            state.copy(
                stressLevel = finalStress,
                backoffUntilMs = System.currentTimeMillis() + backoffMs,
                successStreak = 0,
                timeoutStreak = nextTimeoutStreak,
                resetStreak = nextResetStreak
            )
        }
    }

    fun isProviderStress(error: Throwable): Boolean = classify(error) != StressSignal.NONE

    private enum class StressSignal {
        NONE,
        THROTTLED,
        TIMEOUT,
        CONNECTION_RESET
    }

    private fun classify(error: Throwable): StressSignal {
        return when {
            error is XtreamAuthenticationException -> StressSignal.THROTTLED
            error is XtreamRequestException && error.statusCode in setOf(403, 429) -> StressSignal.THROTTLED
            messageContains(error, "timeout") || messageContains(error, "timed out") -> StressSignal.TIMEOUT
            messageContains(error, "connection reset") || messageContains(error, "reset by peer") -> StressSignal.CONNECTION_RESET
            error is XtreamNetworkException || error is IOException -> StressSignal.TIMEOUT
            else -> StressSignal.NONE
        }
    }

    private fun messageContains(error: Throwable, needle: String): Boolean =
        error.message.orEmpty().contains(needle, ignoreCase = true)
}
