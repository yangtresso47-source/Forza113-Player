package com.streamvault.data.sync

import com.streamvault.data.local.dao.CategoryDao
import com.streamvault.data.local.dao.ChannelDao
import com.streamvault.data.local.dao.MovieDao
import com.streamvault.data.local.dao.SeriesDao
import com.streamvault.data.local.entity.CategoryEntity
import com.streamvault.data.local.entity.ChannelEntity
import com.streamvault.data.local.entity.MovieEntity
import com.streamvault.data.local.entity.SeriesEntity

internal class SyncCatalogStore(
    private val channelDao: ChannelDao,
    private val movieDao: MovieDao,
    private val seriesDao: SeriesDao,
    private val categoryDao: CategoryDao
) {
    suspend fun replaceLiveCatalog(providerId: Long, categories: List<CategoryEntity>?, channels: List<ChannelEntity>): Int {
        categories?.let { upsertCategories(providerId, "LIVE", it) }
        return upsertChannels(providerId, channels)
    }

    suspend fun replaceMovieCatalog(providerId: Long, categories: List<CategoryEntity>?, movies: List<MovieEntity>): Int {
        categories?.let { upsertCategories(providerId, "MOVIE", it) }
        val accepted = upsertMovies(providerId, movies)
        movieDao.restoreWatchProgress(providerId)
        return accepted
    }

    suspend fun replaceSeriesCatalog(providerId: Long, categories: List<CategoryEntity>?, series: List<SeriesEntity>): Int {
        categories?.let { upsertCategories(providerId, "SERIES", it) }
        return upsertSeries(providerId, series)
    }

    suspend fun replaceCategories(providerId: Long, type: String, categories: List<CategoryEntity>) {
        upsertCategories(providerId, type, categories)
    }

    private suspend fun upsertChannels(providerId: Long, incoming: List<ChannelEntity>): Int {
        val existing = channelDao.getByProviderSync(providerId).associateBy { it.streamId }
        val desired = incoming
            .distinctBy { it.streamId }
            .map { fresh ->
                val current = existing[fresh.streamId]
                fresh.copy(
                    id = current?.id ?: 0L,
                    providerId = providerId,
                    isUserProtected = current?.isUserProtected ?: fresh.isUserProtected,
                    errorCount = current?.errorCount ?: fresh.errorCount,
                    qualityOptionsJson = current?.qualityOptionsJson ?: fresh.qualityOptionsJson
                )
            }
        val desiredByRemoteId = desired.associateBy { it.streamId }
        val changed = desired.filter { candidate -> existing[candidate.streamId] != candidate }
        val staleIds = existing
            .filterKeys { it !in desiredByRemoteId.keys }
            .values
            .map { it.id }
        if (changed.isNotEmpty()) {
            channelDao.insertAll(changed)
        }
        deleteIdsInChunks(staleIds, channelDao::deleteByIds)
        return desired.size
    }

    private suspend fun upsertMovies(providerId: Long, incoming: List<MovieEntity>): Int {
        val existing = movieDao.getByProviderSync(providerId).associateBy { it.streamId }
        val desired = incoming
            .distinctBy { it.streamId }
            .map { fresh ->
                val current = existing[fresh.streamId]
                fresh.copy(
                    id = current?.id ?: 0L,
                    providerId = providerId,
                    watchProgress = current?.watchProgress ?: fresh.watchProgress,
                    lastWatchedAt = current?.lastWatchedAt ?: fresh.lastWatchedAt,
                    isUserProtected = current?.isUserProtected ?: fresh.isUserProtected
                )
            }
        val desiredByRemoteId = desired.associateBy { it.streamId }
        val changed = desired.filter { candidate -> existing[candidate.streamId] != candidate }
        val staleIds = existing
            .filterKeys { it !in desiredByRemoteId.keys }
            .values
            .map { it.id }
        if (changed.isNotEmpty()) {
            movieDao.insertAll(changed)
        }
        deleteIdsInChunks(staleIds, movieDao::deleteByIds)
        return desired.size
    }

    private suspend fun upsertSeries(providerId: Long, incoming: List<SeriesEntity>): Int {
        val existing = seriesDao.getByProviderSync(providerId).associateBy { it.seriesId }
        val desired = incoming
            .distinctBy { it.seriesId }
            .map { fresh ->
                val current = existing[fresh.seriesId]
                fresh.copy(
                    id = current?.id ?: 0L,
                    providerId = providerId,
                    isUserProtected = current?.isUserProtected ?: fresh.isUserProtected
                )
            }
        val desiredByRemoteId = desired.associateBy { it.seriesId }
        val changed = desired.filter { candidate -> existing[candidate.seriesId] != candidate }
        val staleIds = existing
            .filterKeys { it !in desiredByRemoteId.keys }
            .values
            .map { it.id }
        if (changed.isNotEmpty()) {
            seriesDao.insertAll(changed)
        }
        deleteIdsInChunks(staleIds, seriesDao::deleteByIds)
        return desired.size
    }

    private suspend fun upsertCategories(providerId: Long, type: String, incoming: List<CategoryEntity>) {
        val existing = categoryDao.getByProviderAndTypeSync(providerId, type).associateBy { it.categoryId }
        val desired = incoming
            .distinctBy { it.categoryId }
            .map { fresh ->
                val current = existing[fresh.categoryId]
                fresh.copy(
                    id = current?.id ?: 0L,
                    providerId = providerId,
                    isUserProtected = current?.isUserProtected ?: fresh.isUserProtected
                )
            }
        val desiredByCategoryId = desired.associateBy { it.categoryId }
        val changed = desired.filter { candidate -> existing[candidate.categoryId] != candidate }
        val staleIds = existing
            .filterKeys { it !in desiredByCategoryId.keys }
            .values
            .map { it.id }
        if (changed.isNotEmpty()) {
            categoryDao.insertAll(changed)
        }
        deleteIdsInChunks(staleIds, categoryDao::deleteByIds)
    }

    private suspend fun deleteIdsInChunks(ids: List<Long>, delete: suspend (List<Long>) -> Unit) {
        ids.chunked(900).forEach { chunk ->
            if (chunk.isNotEmpty()) {
                delete(chunk)
            }
        }
    }
}
