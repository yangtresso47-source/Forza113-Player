package com.streamvault.data.sync

import com.streamvault.domain.model.SyncState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers

internal class SyncStateTracker {
    private data class ProviderStateSnapshot(
        val state: SyncState,
        val updatedAt: Long = System.currentTimeMillis()
    )

    private val scope = CoroutineScope(Dispatchers.Default)
    private val providerSnapshots = MutableStateFlow<Map<Long, ProviderStateSnapshot>>(emptyMap())

    val statesByProvider: StateFlow<Map<Long, SyncState>> = providerSnapshots
        .map { snapshots -> snapshots.mapValues { it.value.state } }
        .stateIn(scope, SharingStarted.Eagerly, emptyMap())

    val aggregateState: StateFlow<SyncState> = providerSnapshots
        .map { snapshots -> aggregate(snapshots.values) }
        .stateIn(scope, SharingStarted.Eagerly, SyncState.Idle)

    fun current(providerId: Long): SyncState = providerSnapshots.value[providerId]?.state ?: SyncState.Idle

    fun publish(providerId: Long, state: SyncState) {
        providerSnapshots.value = providerSnapshots.value + (providerId to ProviderStateSnapshot(state))
    }

    fun reset(providerId: Long? = null) {
        providerSnapshots.value = if (providerId == null) {
            emptyMap()
        } else {
            providerSnapshots.value - providerId
        }
    }

    private fun aggregate(snapshots: Collection<ProviderStateSnapshot>): SyncState {
        if (snapshots.isEmpty()) {
            return SyncState.Idle
        }
        val mostRecentSyncing = snapshots
            .asSequence()
            .filter { it.state is SyncState.Syncing }
            .maxByOrNull { it.updatedAt }
        if (mostRecentSyncing != null) {
            return mostRecentSyncing.state
        }
        return snapshots.maxByOrNull { it.updatedAt }?.state ?: SyncState.Idle
    }

}
