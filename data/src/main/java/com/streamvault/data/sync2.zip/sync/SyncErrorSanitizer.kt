package com.streamvault.data.sync

import com.streamvault.data.remote.xtream.XtreamAuthenticationException
import com.streamvault.data.remote.xtream.XtreamNetworkException
import com.streamvault.data.remote.xtream.XtreamParsingException
import com.streamvault.data.remote.xtream.XtreamRequestException
import java.net.URI

internal class SyncErrorSanitizer {
    fun userMessage(error: Throwable?, fallback: String): String {
        val projected = when (error) {
            null -> fallback
            is XtreamAuthenticationException -> "Provider authentication failed."
            is XtreamParsingException -> "Provider returned an unreadable response."
            is XtreamRequestException -> "Provider rejected the request."
            is XtreamNetworkException -> "Provider connection failed."
            else -> error.message ?: fallback
        }
        return sanitize(projected).ifBlank { fallback }
    }

    fun throwableMessage(error: Throwable?): String = sanitize(error?.message)

    fun sanitize(message: String?): String {
        if (message.isNullOrBlank()) {
            return "<empty>"
        }
        return message
            .replace(Regex("""https?://[^\s]+""", RegexOption.IGNORE_CASE)) { match ->
                redactUrl(match.value)
            }
            .replace(Regex("""([?&](username|password|token|auth|key)=[^&\s]+)""", RegexOption.IGNORE_CASE), "<redacted-param>")
            .replace(Regex("""(?i)\b(user(name)?|password|token|auth|key)\s*[=:]\s*[^,\s]+"""), "<redacted-credential>")
    }

    private fun redactUrl(url: String): String {
        return runCatching {
            val parsed = URI(url)
            val scheme = parsed.scheme ?: "https"
            val host = parsed.host ?: return@runCatching "<redacted-url>"
            val path = parsed.path.orEmpty()
            "$scheme://$host$path"
        }.getOrDefault("<redacted-url>")
    }
}
