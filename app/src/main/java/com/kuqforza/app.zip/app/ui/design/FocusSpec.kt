package com.streamvault.app.ui.design

import androidx.compose.ui.unit.dp

object FocusSpec {
    const val FocusedScale = 1.06f
    const val PressedScale = 0.98f
    val BorderWidth = 3.dp
    val CardBorderWidth = 4.dp
}
